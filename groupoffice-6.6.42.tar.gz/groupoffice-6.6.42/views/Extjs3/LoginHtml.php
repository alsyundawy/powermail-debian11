<?php
require \GO::view()->getTheme()->getPath().'Layout.php';
