<?php
$primaryColor = "#000";
require(__DIR__ . "/../Paper/Layout.php");