<?php
$useThemeSettings = true;
$density = 110;
require(__DIR__ . "/../Paper/Layout.php");