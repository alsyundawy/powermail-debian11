Ext.onReady(function(){
	ResetPasswordDialog = new GO.dialog.ResetPasswordDialog();
	ResetPasswordDialog.show();
});
