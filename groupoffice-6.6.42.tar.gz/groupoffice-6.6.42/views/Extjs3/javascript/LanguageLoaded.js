//this file just fires an event when all the language files have been loaded so a module may override the variables
GO.moduleManager.fireEvent('languageLoaded');
