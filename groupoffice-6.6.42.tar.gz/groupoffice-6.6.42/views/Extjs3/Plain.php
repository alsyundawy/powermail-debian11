<?php
require("externalHeader.php");

echo $data;

require("externalFooter.php");
?>
